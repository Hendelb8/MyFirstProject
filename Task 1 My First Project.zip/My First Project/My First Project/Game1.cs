﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections;

namespace My_First_Project
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        int currentFPS = 0;
        float fpsTimer = 0;
        int fpsCounter = 0;

        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        const int STATE_SPLASH = 0;
        const int STATE_GAME = 1;
        const int STATE_GAMEOVER = 2;
        const int STATE_WIN = 3;

        SpriteFont arialFont;
        Texture2D shipTexture;
        Texture2D asteroidTexture;

        float playerSpeed = 100;
        float playerRotateSpeed = 2;
        Vector2 playerPosition = new Vector2(0, 0);

        public int gameState { get; private set; }

        Vector2 playerOffset = new Vector2(0, 0);
        float playerAngle = 0;
        bool playerAlive = true;

        float asteroidSpeed = 30;
        ArrayList asteroidPositions = new ArrayList();
        ArrayList asteroidVelocities = new ArrayList();
        Vector2 asteroidOffset = new Vector2(0, 0);
        bool asteroidAlive = false;
        float asteroidsKilled = 0;

        Texture2D bulletTexture;
        float bulletSpeed = 400;
        //Vector2 bulletPosition = new Vector2(0, 0);
        // Vector2 bulletVelocity = new Vector2(0, 0);
        ArrayList bulletVelocities = new ArrayList();
        ArrayList bulletPositions = new ArrayList();
        bool bulletAlive = false;
        float canshootTimer = 0.5f;


        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            this.IsFixedTimeStep = true;
            this.graphics.SynchronizeWithVerticalRetrace = true;
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            playerPosition = new Vector2(
                           graphics.GraphicsDevice.Viewport.Width / 2,
                           graphics.GraphicsDevice.Viewport.Height / 2);
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            arialFont = Content.Load<SpriteFont>("Arial");
            shipTexture = Content.Load<Texture2D>("ship");
            asteroidTexture = Content.Load<Texture2D>("rock_large");
            bulletTexture = Content.Load<Texture2D>("bullet");

            //find the width and height of the ship so we can calculate the offset
            //(so that when we draw the ship, the player position refers to the center of the ship)
            playerOffset = new Vector2(shipTexture.Width / 2, shipTexture.Height / 2);

            asteroidOffset = new Vector2(asteroidTexture.Width / 2, asteroidTexture.Height / 2);

            System.Random random = new System.Random();

            {
                for (int i = 0; i < 10; i++) // create some asteroids
                {
                    Vector2 randDirection = new Vector2(
                           random.Next(-100, 100), random.Next(-100, 100));
                    randDirection.Normalize();

                    Vector2 asteroidPosition =
                            randDirection * graphics.GraphicsDevice.Viewport.Height;
                    asteroidPositions.Add(asteroidPosition);

                    Vector2 velocity = (playerPosition - asteroidPosition);
                    velocity.Normalize();
                    velocity *= asteroidSpeed;

                    asteroidVelocities.Add(velocity);
                }
            }
        }


        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        private void UpdatePlayer(float deltaTime)
        {
            float currentSpeed = 0;

            if (Keyboard.GetState().IsKeyDown(Keys.Up) == true)
            {
                currentSpeed = playerSpeed * deltaTime;
            }
            else if (Keyboard.GetState().IsKeyDown(Keys.Down) == true)
            {
                currentSpeed = -playerSpeed * deltaTime;
            }

            if (Keyboard.GetState().IsKeyDown(Keys.Left) == true)
            {
                playerAngle -= playerRotateSpeed * deltaTime;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.Right) == true)
            { playerAngle += playerRotateSpeed * deltaTime; }

            // figure out the x and y movement based on the current rotation
            // (so that if the ship is moving forward, then it will move forward according to its rotation.
            // Without this, the ship would just move up the screen when we pressed 'up', regardless of which way it was rotated.
            // calculate sin and cos for the player's current rotation     
            Vector2 playerDirection = new Vector2(-(float)System.Math.Sin(playerAngle),
                                                    (float)System.Math.Cos(playerAngle));
            playerDirection.Normalize();

            //shoot a bullet
            canshootTimer -= 1 * deltaTime;
            if (Keyboard.GetState().IsKeyDown(Keys.Space) == true && canshootTimer < 0)
            {
                Vector2 bulletPosition = playerPosition;
                Vector2 bulletVelocity = playerDirection * bulletSpeed;
                bulletPositions.Add(bulletPosition);
                bulletVelocities.Add(bulletVelocity);
                bulletAlive = true;
            }

            // the Vector2 class also has a normalize function   
            Vector2 direction = new Vector2(40, 30);
            direction.Normalize();

            Vector2 playerVelocity = playerDirection * currentSpeed;
            playerPosition += playerVelocity;
        }

        private void UpdateAsteroids(float deltaTime)
        {
            for (int asteroidIdx = 0; asteroidIdx < asteroidPositions.Count; asteroidIdx++)
            {
                // the one thing we have to be aware of here is that the Vector2
                // (position) is stored in the ArrayList as an object so we can't
                // modify any of its variables. We need to get a copy of the Vector2,
                // modify the copy, then overwrite the Vector2 in the ArrayList with
                // the updated copy. (Same goes for the velocity)
                Vector2 position = (Vector2)asteroidPositions[asteroidIdx];
                Vector2 velocity = (Vector2)asteroidVelocities[asteroidIdx];

                position += velocity * deltaTime;
                asteroidPositions[asteroidIdx] = position;
                // if the asteroid goes off the screen, reverse the velocity
                if (position.X < 0 && velocity.X < 0 ||
                position.X > graphics.GraphicsDevice.Viewport.Width && velocity.X > 0)
                {
                    velocity.X = -velocity.X;
                    asteroidVelocities[asteroidIdx] = velocity;
                }
                if (position.Y < 0 && velocity.Y < 0 ||
                position.Y > graphics.GraphicsDevice.Viewport.Height && velocity.Y > 0)
                {
                    velocity.Y = -velocity.Y;
                    asteroidVelocities[asteroidIdx] = velocity;
                }
            }
        }

        private void UpdateBullets(float deltaTime)
        {
            // if (bulletAlive == false)
            //  return;

            // bulletPosition += bulletVelocity * deltaTime;

            // if (bulletPosition.X < 0 ||
            // bulletPosition.X > graphics.GraphicsDevice.Viewport.Width ||
            //bulletPosition.Y < 0 ||
            // bulletPosition.Y > graphics.GraphicsDevice.Viewport.Height)
            // {
            //  bulletAlive = false;
            // }

            for (int bulletIdx = 0; bulletIdx < bulletPositions.Count; bulletIdx++)
            {
                // the one thing we have to be aware of here is that the Vector2
                // (position) is stored in the ArrayList as an object so we can't
                // modify any of its variables. We need to get a copy of the Vector2,
                // modify the copy, then overwrite the Vector2 in the ArrayList with
                // the updated copy. (Same goes for the velocity)
                Vector2 bulletpos = (Vector2)bulletPositions[bulletIdx];
                Vector2 bulletvel = (Vector2)bulletVelocities[bulletIdx];

                bulletpos += bulletvel * deltaTime;
                bulletPositions[bulletIdx] = bulletpos;
                // if the bullet goes off the screen, remove the bullet
                if (bulletpos.X < 0 && bulletvel.X < 0 ||
                bulletpos.X > graphics.GraphicsDevice.Viewport.Width && bulletvel.X > 0)
                {
                    bulletPositions.RemoveAt(bulletIdx);
                    bulletVelocities.RemoveAt(bulletIdx);
                }
                if (bulletpos.Y < 0 && bulletvel.Y < 0 ||
                bulletpos.Y > graphics.GraphicsDevice.Viewport.Height && bulletvel.Y > 0)
                {
                    bulletPositions.RemoveAt(bulletIdx);
                    bulletVelocities.RemoveAt(bulletIdx);

                }
            }


        }

        private bool IsColliding(Vector2 position1, float radius1, Vector2 position2, float radius2)
        {
            Vector2 distance = position2 - position1;

            if (distance.Length() < radius1 + radius2)
            {
                //the distance between these two circles is less than their radii, so they must be colliding
                return true;
            }
            //else the two circles are not colliding
            return false;
        }

        private bool IsColliding(Rectangle rect1, Rectangle rect2)
        {
            if (rect1.X + rect1.Width < rect2.X ||
                rect1.X > rect2.X + rect2.Width ||
                rect1.Y + rect1.Height < rect2.Y ||
                rect1.Y > rect2.Y + rect2.Height)
            {
                //these two rectangles are not collidinng
                return false;
            }
            //else, the two AABB rectangles overlap, therefore collision
            return true;
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // TODO: Add your update logic here
            float deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;

            //calculate the current FPS (frames per second)
            // This is Debug code, remove this before submission
            fpsTimer += deltaTime;
            if (fpsTimer > 1.0f)
            {
                fpsTimer = 0f;
                currentFPS = fpsCounter;
                fpsCounter = 0;
            }
            fpsCounter++;

            switch (gameState)
            {
                case STATE_SPLASH:
                    UpdateSplashState(deltaTime);
                    break;
                case STATE_GAME:
                    UpdateGameState(deltaTime);
                    break;
                case STATE_GAMEOVER:
                    UpdateGameOverState(deltaTime);
                    break;
                case STATE_WIN:
                    UpdateWinState(deltaTime);
                    break;
            }

            base.Update(gameTime);
        }

        private void UpdateSplashState(float deltaTime)
        {
            if (Keyboard.GetState().IsKeyDown(Keys.Enter) == true)
            {
                gameState = STATE_GAME;
                asteroidsKilled = 0;
            }
        }

        private void DrawSplashState(SpriteBatch spriteBatch)
        {
            spriteBatch.DrawString(arialFont, "Press Enter to Play", new Vector2(300, 150), Color.White);
        }

        private void UpdateGameState(float deltaTime)
        {
            UpdatePlayer(deltaTime);
            UpdateAsteroids(deltaTime);
            UpdateBullets(deltaTime);

            for (int bulletIdx = 0; bulletIdx < bulletPositions.Count; bulletIdx++)
            {
                Vector2 bulletpos = (Vector2)bulletPositions[bulletIdx];
                Rectangle bulletRect = new Rectangle((int)bulletpos.X,
                    (int)bulletpos.Y,
                    bulletTexture.Bounds.Width,
                    bulletTexture.Bounds.Height);
                // check for collisions
                for (int asteroidIdx = 0; asteroidIdx < asteroidPositions.Count;
                asteroidIdx++)
                {
                    Vector2 position = (Vector2)asteroidPositions[asteroidIdx];
                    Rectangle asteroid = new Rectangle(
                    (int)(position.X - asteroidOffset.X),
                    (int)(position.Y - asteroidOffset.Y),
                    asteroidTexture.Width, asteroidTexture.Height);
                    if (IsColliding(bulletRect, asteroid) == true)
                    {
                        // bullet and asteroid are colliding, destroy both
                        bulletPositions.RemoveAt(bulletIdx);
                        bulletVelocities.RemoveAt(bulletIdx);
                        asteroidPositions.RemoveAt(asteroidIdx);
                        asteroidVelocities.RemoveAt(asteroidIdx);
                        asteroidsKilled = asteroidsKilled + 1;
                        // once we hit the first thing and kill the bullet,
                        // there's no point in checking the rest of the ArrayList
                        break;
                    }

                }

            }

            Rectangle playerRect = new Rectangle((int)playerPosition.X,
                (int)playerPosition.Y,
                shipTexture.Bounds.Width,
                shipTexture.Bounds.Height);
            if (playerAlive == true)
            {
                for (int asteroidIdx = 0; asteroidIdx < asteroidPositions.Count; asteroidIdx++)
                {
                    Vector2 position = (Vector2)asteroidPositions[asteroidIdx];
                    Rectangle asteroid = new Rectangle(
                    (int)(position.X - asteroidOffset.X),
                    (int)(position.Y - asteroidOffset.Y),
                    asteroidTexture.Width, asteroidTexture.Height);
                    if (IsColliding(playerRect, asteroid) == true)
                    {
                        // player and asteroid are colliding, destroy both
                        playerAlive = false;
                        asteroidPositions.RemoveAt(asteroidIdx);
                        asteroidVelocities.RemoveAt(asteroidIdx);
                        // player is dead,
                        // there's no point in checking the rest of the ArrayList
                        break;
                    }
                }
            }

            if (playerAlive == false)
            {
                gameState = STATE_GAMEOVER;
            }


            if (asteroidsKilled == 10)
            {
                // no more asteroids, end the 'game'
                gameState = STATE_WIN;
            }
        }
        private void DrawGameState(SpriteBatch spriteBatch)
        {
            // if (bulletAlive == true)
            //{
            //  spriteBatch.Draw(bulletTexture, bulletPosition, null, null, null, 0, null, Color.White);
            // }
            spriteBatch.Draw(shipTexture, playerPosition, null, null, playerOffset, playerAngle, null, Color.White);
            for (int asteroidIdx = 0; asteroidIdx < asteroidPositions.Count;
            asteroidIdx++)
            {
                Vector2 position = (Vector2)asteroidPositions[asteroidIdx];
                spriteBatch.Draw(asteroidTexture, position, null, null, asteroidOffset, 0, null, Color.White);
            }
            for (int bulletIdx = 0; bulletIdx < bulletPositions.Count; bulletIdx++)
            {
                Vector2 position = (Vector2)bulletPositions[bulletIdx];
                //spriteBatch.Draw(bulletTexture, bulletpos, null, null, null, 0, null, Color.White);
            }
        }
        private void UpdateGameOverState(float deltaTime)
        {
            if (Keyboard.GetState().IsKeyDown(Keys.Enter) == true)
            {
                gameState = STATE_SPLASH;
            }
        }

        private void UpdateWinState(float deltaTime)
        {
            if (Keyboard.GetState().IsKeyDown(Keys.Enter) == true)
            {
                gameState = STATE_SPLASH;
            }
        }

        private void DrawGameOverState(SpriteBatch spriteBatch)
        {
            spriteBatch.DrawString(arialFont, "Game Over", new Vector2(300, 150), Color.White);
        }


        private void DrawWinState(SpriteBatch spriteBatch)
        {
            spriteBatch.DrawString(arialFont, "You Win!", new Vector2(300, 150), Color.White);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here
            spriteBatch.Begin();

            switch (gameState)
            {
                case STATE_SPLASH:
                    DrawSplashState(spriteBatch);
                    break;
                case STATE_GAME:
                    DrawGameState(spriteBatch);
                    break;
                case STATE_GAMEOVER:
                    DrawGameOverState(spriteBatch);
                    break;
                case STATE_WIN:
                    DrawWinState(spriteBatch);
                    break;
            }
            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
